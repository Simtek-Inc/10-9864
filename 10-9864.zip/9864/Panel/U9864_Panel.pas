unit U9864_Panel;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls;

type
  TfrmPanel = class(TForm)
    pnlDevice: TPanel;
    RS2: TShape;
    lbl_TEST: TLabel;
    lbl_NORM: TLabel;
    RS1: TShape;
    lbl_man_L: TLabel;
    lbl_auto_L: TLabel;
    lbl_map_R: TLabel;
    lbl_man_R: TLabel;
    lbl_auto_R: TLabel;
    pot_gain_L: TShape;
    pot_gain_R: TShape;
    lbl_gain_R: TLabel;
    pot_alt_L: TShape;
    lbl_wxr_R: TLabel;
    potVal_alt_L: TLabel;
    potVal_gain_L: TLabel;
    potVal_gain_R: TLabel;
    potVal_alt_R: TLabel;
    lbl_wxr_L: TLabel;
    Shape1: TShape;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Shape2: TShape;
    Shape3: TShape;
    Shape4: TShape;
    Shape5: TShape;
    Shape6: TShape;
    Shape7: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Label5: TLabel;
    Shape10: TShape;
    Shape11: TShape;
    Shape12: TShape;
    Shape13: TShape;
    Shape14: TShape;
    Shape15: TShape;
    Shape16: TShape;
    Shape17: TShape;
    Shape18: TShape;
    Shape20: TShape;
    Shape21: TShape;
    Shape22: TShape;
    Shape23: TShape;
    Shape24: TShape;
    Shape25: TShape;
    Shape26: TShape;
    Shape27: TShape;
    Shape28: TShape;
    Shape29: TShape;
    Shape30: TShape;
    Shape31: TShape;
    Shape32: TShape;
    Shape33: TShape;
    Shape34: TShape;
    Shape35: TShape;
    Shape36: TShape;
    Shape37: TShape;
    Shape38: TShape;
    Shape39: TShape;
    Shape40: TShape;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    Shape19: TShape;
    Shape41: TShape;
    Shape42: TShape;
    Shape43: TShape;
    Shape44: TShape;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmPanel: TfrmPanel;

implementation

{$R *.dfm}

end.
